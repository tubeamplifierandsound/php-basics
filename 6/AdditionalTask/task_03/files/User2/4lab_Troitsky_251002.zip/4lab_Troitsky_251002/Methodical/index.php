<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<form method="POST">
    <label>
        Enter text<br>
        <textarea name="inp_text" cols="35" rows="20"><?php include 'text_processing.php'?>
</body>
</html>